// alert("HOLA Mundo");

let producto = "Nombre del pproducto";

let disponible;

disponible = true;
// tipo boleano

disponible = "No hay producto";
//

let camiseta = 2;
let pantalon = "verde";
let zapatos = true;

console.log("PrimerEtapa:",camiseta,pantalon)
console.log("Zapatos",zapatos)

let patata;

console.log("ola",patata)

const constante = 1;
console.log("VariableTipoConstante",constante);